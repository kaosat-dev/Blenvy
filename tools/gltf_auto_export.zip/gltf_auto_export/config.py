scene_key = "auto_gltfExportSettings"
