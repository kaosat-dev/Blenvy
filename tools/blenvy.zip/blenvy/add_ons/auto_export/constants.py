TEMPSCENE_PREFIX = "__temp_scene"

#hard coded custom properties to ignore on export
custom_properties_to_filter_out = [
    'glTF2ExportSettings', 
    'assets', 'user_assets', 'Generated_assets', 'generated_assets', 
    'components_meta', 'Components_meta', 
    '_combine', 'template', 
    'Blenvy_scene_type', 'blenvy_scene_type',
    'materials_path', 'export_path',
    ]
