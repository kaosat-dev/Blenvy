# FIXME: not sure, hard coded exclude list ?
HIDDEN_COMPONENTS = ['Parent', 'Children']