# Levels

## What are levels ?

- any Blender scene that has been tagged as a level in the Blenvy settings

## How to create levels ?

- create a Blender scene
- tag it as a level in the Blenvy settings
- place blueprint/collection instances or any normal Blender mesh/object in the scene
- just save your file